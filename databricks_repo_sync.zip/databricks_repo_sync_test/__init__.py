def plus_one(a):
    return a + 1
